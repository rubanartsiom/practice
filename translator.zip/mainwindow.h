#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_inputEnglish_textChanged(const QString &text);

private:
    Ui::MainWindow *ui;

    int parseDay(const QString &token);
    int parseMonth(const QString &token);
    bool parseYearToken(const QString &token, int &currentYear);

    QString getRuDay(int day);
    QString getRuMonth(int month);
    QString getRuYear(int year);
};

#endif // MAINWINDOW_H