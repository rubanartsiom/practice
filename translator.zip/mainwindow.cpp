#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStringList>
#include <QRegularExpression>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Устанавливаем плейсхолдеры для понятности
    ui->outUsDigital->setText("YYYY/MM/DD");
    ui->outRuText->setText("...");
    ui->outRuDigital->setText("DD/MM/YYYY");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_inputEnglish_textChanged(const QString &text)
{
    int day = 0;
    int month = 0;
    int year = 0;

    // Разбиваем введенный текст на слова, игнорируя лишние пробелы
    QStringList tokens = text.toLower().split(QRegularExpression("\\s+"), Qt::SkipEmptyParts);

    for (const QString &token : tokens) {
        if (token == "of") continue;

        // Ищем месяц
        if (month == 0) {
            int m = parseMonth(token);
            if (m > 0) { month = m; continue; }
        }

        // Если месяц уже найден, следующие числа скорее всего относятся к году
        if (month > 0) {
            if (parseYearToken(token, year)) continue;
        }

        // Ищем день, если он еще не найден
        if (day == 0) {
            int d = parseDay(token);
            if (d > 0) day = d;
        }
    }

    // --- ФОРМИРОВАНИЕ ВЫВОДА ---

    // 1. Американский формат (ГГГГ/ММ/ДД)
    QString usYear  = (year > 0)  ? QString("%1").arg(year, 4, 10, QChar('0')) : "YYYY";
    QString usMonth = (month > 0) ? QString("%1").arg(month, 2, 10, QChar('0')) : "MM";
    QString usDay   = (day > 0)   ? QString("%1").arg(day, 2, 10, QChar('0')) : "DD";
    ui->outUsDigital->setText(usYear + "/" + usMonth + "/" + usDay);

    // 2. Русский цифровой формат (ДД/ММ/ГГГГ)
    ui->outRuDigital->setText(usDay + "/" + usMonth + "/" + usYear);

    // 3. Русский текстовый формат
    QString ruText = "";
    if (day > 0) ruText += getRuDay(day) + " ";
    if (month > 0) ruText += getRuMonth(month) + " ";
    if (year > 0) ruText += getRuYear(year);

    ui->outRuText->setText(ruText.trimmed());
}

// --- ЛОГИКА ПАРСИНГА АНГЛИЙСКОГО ---

int MainWindow::parseDay(const QString &t) {
    // Порядок важен для частичных совпадений. 'seven' стоит раньше 'six',
    // поэтому при вводе 's' приоритет отдается семерке.
    if (QString("seventh").startsWith(t) || QString("seven").startsWith(t)) return 7;
    if (QString("sixteenth").startsWith(t) || QString("sixteen").startsWith(t)) return 16;
    if (QString("sixth").startsWith(t) || QString("six").startsWith(t)) return 6;
    if (QString("second").startsWith(t) || QString("two").startsWith(t)) return 2;

    if (QString("first").startsWith(t) || QString("one").startsWith(t)) return 1;
    if (QString("third").startsWith(t) || QString("three").startsWith(t)) return 3;
    if (QString("fourth").startsWith(t) || QString("four").startsWith(t)) return 4;
    if (QString("fifth").startsWith(t) || QString("five").startsWith(t)) return 5;
    if (QString("eighth").startsWith(t) || QString("eight").startsWith(t)) return 8;
    if (QString("ninth").startsWith(t) || QString("nine").startsWith(t)) return 9;
    if (QString("tenth").startsWith(t) || QString("ten").startsWith(t)) return 10;

    if (QString("twentieth").startsWith(t) || QString("twenty").startsWith(t)) return 20;
    if (QString("thirtieth").startsWith(t) || QString("thirty").startsWith(t)) return 30;

    return 0;
}

int MainWindow::parseMonth(const QString &t) {
    if (QString("january").startsWith(t)) return 1;
    if (QString("february").startsWith(t)) return 2;
    if (QString("march").startsWith(t)) return 3;
    if (QString("april").startsWith(t)) return 4;
    if (QString("may").startsWith(t)) return 5;
    // 'july' проверяем до 'june', чтобы при 'j' или 'ju' появлялся Июль, как в твоем примере
    if (QString("july").startsWith(t)) return 7;
    if (QString("june").startsWith(t)) return 6;
    if (QString("august").startsWith(t)) return 8;
    if (QString("september").startsWith(t)) return 9;
    if (QString("october").startsWith(t)) return 10;
    if (QString("november").startsWith(t)) return 11;
    if (QString("december").startsWith(t)) return 12;
    return 0;
}

bool MainWindow::parseYearToken(const QString &t, int &currentYear) {
    // Наш век (2000-2099)
    if (QString("two").startsWith(t) || QString("thousand").startsWith(t)) {
        if (currentYear == 0) currentYear = 2000;
        return true;
    }
    if (QString("twenty").startsWith(t)) {
        if (currentYear < 2020) currentYear = 2020;
        return true;
    }
    // Добавляем единицы к году
    int unit = 0;
    if (QString("one").startsWith(t)) unit = 1;
    else if (QString("two").startsWith(t)) unit = 2;
    else if (QString("three").startsWith(t)) unit = 3;
    else if (QString("four").startsWith(t)) unit = 4;
    else if (QString("five").startsWith(t)) unit = 5;
    else if (QString("six").startsWith(t)) unit = 6;
    else if (QString("seven").startsWith(t)) unit = 7;
    else if (QString("eight").startsWith(t)) unit = 8;
    else if (QString("nine").startsWith(t)) unit = 9;

    if (unit > 0) {
        if (currentYear == 0) currentYear = 2000;
        // Заменяем последнюю цифру
        currentYear = (currentYear / 10) * 10 + unit;
        return true;
    }
    return false;
}

// --- ЛОГИКА ПЕРЕВОДА НА РУССКИЙ ---

QString MainWindow::getRuDay(int day) {
    QString days[] = {
        "", "первое", "второе", "третье", "четвертое", "пятое", "шестое", "седьмое", "восьмое", "девятое", "десятое",
        "одиннадцатое", "двенадцатое", "тринадцатое", "четырнадцатое", "пятнадцатое", "шестнадцатое", "семнадцатое", "восемнадцатое", "девятнадцатое", "двадцатое"
    };
    if (day <= 20) return days[day];
    if (day == 30) return "тридцатое";
    if (day > 20 && day < 30) return "двадцать " + days[day - 20];
    if (day == 31) return "тридцать первое";
    return "";
}

QString MainWindow::getRuMonth(int month) {
    QString months[] = {
        "", "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    };
    if (month >= 1 && month <= 12) return months[month];
    return "";
}

QString MainWindow::getRuYear(int year) {
    if (year < 2000 || year > 2099) return "";

    QString prefix = "две тысячи ";
    int remainder = year % 100;

    if (remainder == 0) return "двухтысячного года";

    QString units[] = {"", "первого", "второго", "третьего", "четвертого", "пятого", "шестого", "седьмого", "восьмого", "девятого", "десятого",
                       "одиннадцатого", "двенадцатого", "тринадцатого", "четырнадцатого", "пятнадцатого", "шестнадцатого", "семнадцатого", "восемнадцатого", "девятнадцатого"};
    QString tens[] = {"", "", "двадцать", "тридцать", "сорок", "пятьдесят", "шестьдесят", "семьдесят", "восемьдесят", "девяносто"};

    QString yearStr = prefix;
    if (remainder < 20) {
        yearStr += units[remainder];
    } else {
        int t = remainder / 10;
        int u = remainder % 10;
        if (u == 0) {
            // Для круглых десятков (2020, 2030) окончания меняются
            QString tensOrdinal[] = {"", "", "двадцатого", "тридцатого", "сорокового", "пятидесятого", "шестидесятого", "семидесятого", "восьмидесятого", "девяностого"};
            yearStr += tensOrdinal[t];
        } else {
            yearStr += tens[t] + " " + units[u];
        }
    }
    return yearStr + " года";
}